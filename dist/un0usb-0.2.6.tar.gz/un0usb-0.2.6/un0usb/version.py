__version_info__ = ('0', '2', '6')
__version__ = '.'.join(__version_info__)